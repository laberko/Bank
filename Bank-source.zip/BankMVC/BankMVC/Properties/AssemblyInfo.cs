﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("BankMVC")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("BankMVC")]
[assembly: AssemblyCopyright("© , 2017")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("88cd9306-8a18-4ccd-9f9e-adef9ee365e6")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
